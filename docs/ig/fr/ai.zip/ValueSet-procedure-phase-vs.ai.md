# TAUSSIG — Phases procédurales - TAUSSIG — Implementation Guide (POC Cathétérisme) v0.8.0

## ValueSet: TAUSSIG — Phases procédurales (Expérimental) 

 **References** 

* [Phase procédurale (mesure)](StructureDefinition-procedurePhase.md)

### Définition logique (CLD)

 

### Expansion

-------

 [Description du (des) tableau(x) ci-dessus](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "procedure-phase-vs",
  "url" : "https://taussig/fhir/ValueSet/procedure-phase-vs",
  "version" : "0.8.0",
  "name" : "ProcedurePhaseVS",
  "title" : "TAUSSIG — Phases procédurales",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-09T08:39:58+01:00",
  "publisher" : "Projet TAUSSIG",
  "description" : "Jeu de valeurs « TAUSSIG — Phases procédurales » utilisé par les profils TAUSSIG.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://taussig/fhir/CodeSystem/procedure-phase"
    }]
  }
}

```
